#' Function to pick outliers
#'
#' @description Successively using linear regression and decision tree this function is able to pick outliers from two metric dataset. originally built to work a the z-score and the log2 fold-change it is possible to feed the function with others metrics. The decision tree can be also custom.
#'
#' @param zscore data frame of the same size as the initial dataset. The z-score can be compute with the function Zscore.
#' @param l2fc data frame of the same size as the initial dataset. The log2 fold-change can be compute with the function L2FC.
#' @param SequencingTable a read counts table with the transcripts in row and the samples in column.
#' @param ReconstructedTable the reconstructed table generate by an autoencoder.
#' @param decision_tree function containing a custom decision tree. Check the help of the function my_tree for more information.
#' @param nb_pval argument allowing to have an additional column in the result. The column is an estimation of the P-value using negative binomial distribution.
#'
#' @return Data frame containing only rows predict as outliers.
#' @importFrom stats cooks.distance
#' @importFrom stats dfbetas
#' @importFrom stats hatvalues
#' @importFrom stats lm
#' @importFrom stats rstandard
#' @importFrom stats complete.cases
#' @importFrom stats pnbinom
#' @importFrom progress progress_bar
#'
#' @examples
#' SequencingTable <- ExampleAbeilleDataSet
#' ReconstructedTable <- ExampleAbeilleReconstructed
#' zscore <- Zscore(SequencingTable,ReconstructedTable)
#' l2fc <- L2FC(SequencingTable,ReconstructedTable)
#' genedisp <- GeneDisp(SequencingTable)
#' outliers <- PickOutliers(zscore,l2fc,SequencingTable, ReconstructedTable,
#' decision_tree = my_tree, nb_pval=genedisp)
#' print(head(outliers))
#' @export

PickOutliers <- function(zscore, l2fc, SequencingTable, ReconstructedTable, decision_tree = my_tree, nb_pval = FALSE){
  if (nb_pval[1] == FALSE){
  i=1
  var1 <- zscore[i,]
  var2 <- l2fc[i,]
  linear_reg <- lm(var2~var1)
  DataReturn <- data.frame(Sample = NA,
                           Transcript = NA,
                           value = NA,
                           reconstruction = NA,
                           zscore=NA,
                           l2fc=NA,
                           typeerror=NA,
                           cooksD=NA,
                           hat=NA,
                           dfbetas_intercept=NA,
                           dfbetas_var=NA,
                           predict=NA)
  LinearRegression_data <- data.frame(Sample = colnames(SequencingTable),
                                      Transcript = rep(row.names(SequencingTable)[i],ncol(SequencingTable)),
                                      value = as.numeric(SequencingTable[i,]),
                                      reconstruction = as.numeric(ReconstructedTable[i,]),
                                      zscore=var1,
                                      l2fc=var2,
                                      typeerror=rstandard(linear_reg),
                                      cooksD=cooks.distance(linear_reg),
                                      hat=hatvalues(linear_reg),
                                      dfbetas_intercept=dfbetas(linear_reg)[,1],
                                      dfbetas_var=dfbetas(linear_reg)[,2],
                                      row.names = NULL)
  LinearRegression_data['predict'] <- decision_tree(LinearRegression_data)
  LinearRegression_data <- LinearRegression_data[LinearRegression_data$predict == TRUE,]
  LinearRegression_data <- LinearRegression_data[complete.cases(LinearRegression_data),]
  DataReturn <- rbind(DataReturn,LinearRegression_data)
  pb <- progress_bar$new(total = dim(SequencingTable)[1] - 1)
  pb$tick(0)
  for (i in 2:dim(SequencingTable)[1]){
    pb$tick()
    var1 <- zscore[i,]
    var2 <- l2fc[i,]
    linear_reg <- lm(var2~var1)
    LinearRegression_data <- data.frame(Sample = colnames(SequencingTable),
                                        Transcript = rep(row.names(SequencingTable)[i],ncol(SequencingTable)),
                                        value = as.numeric(SequencingTable[i,]),
                                        reconstruction = as.numeric(ReconstructedTable[i,]),
                                        zscore=var1,
                                        l2fc=var2,
                                        typeerror=rstandard(linear_reg),
                                        cooksD=cooks.distance(linear_reg),
                                        hat=hatvalues(linear_reg),
                                        dfbetas_intercept=dfbetas(linear_reg)[,1],
                                        dfbetas_var=dfbetas(linear_reg)[,2],
                                        row.names = NULL)
    LinearRegression_data['predict'] <- decision_tree(LinearRegression_data)
    LinearRegression_data <- LinearRegression_data[LinearRegression_data$predict == TRUE,]
    LinearRegression_data <- LinearRegression_data[complete.cases(LinearRegression_data), ]
    DataReturn <- rbind(DataReturn,LinearRegression_data)}
  DataReturn <- DataReturn[-1,]
  row.names(DataReturn) <- NULL
  return(DataReturn)}else if(class(nb_pval[1]) == "numeric"){
    if (class(SequencingTable) == "data.frame"){SequencingTable <- as.matrix(SequencingTable)}
    if (class(ReconstructedTable) == "data.frame"){ReconstructedTable <- as.matrix(ReconstructedTable)}
    i=1
    var1 <- zscore[i,]
    var2 <- l2fc[i,]
    linear_reg <- lm(var2~var1)
    DataReturn <- data.frame(Sample = NA,
                             Transcript = NA,
                             value = NA,
                             reconstruction = NA,
                             zscore=NA,
                             l2fc=NA,
                             typeerror=NA,
                             cooksD=NA,
                             hat=NA,
                             dfbetas_intercept=NA,
                             dfbetas_var=NA,
                             nb_pval = NA,
                             predict=NA)
    LinearRegression_data <- data.frame(Sample = colnames(SequencingTable),
                                        Transcript = rep(row.names(SequencingTable)[i],ncol(SequencingTable)),
                                        value = as.numeric(SequencingTable[i,]),
                                        reconstruction = as.numeric(ReconstructedTable[i,]),
                                        zscore=var1,
                                        l2fc=var2,
                                        typeerror=rstandard(linear_reg),
                                        cooksD=cooks.distance(linear_reg),
                                        hat=hatvalues(linear_reg),
                                        dfbetas_intercept=dfbetas(linear_reg)[,1],
                                        dfbetas_var=dfbetas(linear_reg)[,2],
                                        nb_pval = pnbinom(q = SequencingTable[i,], size = nb_pval[i], mu = ReconstructedTable[i,]),
                                        row.names = NULL)
    LinearRegression_data['predict'] <- decision_tree(LinearRegression_data)
    LinearRegression_data <- LinearRegression_data[LinearRegression_data$predict == TRUE,]
    LinearRegression_data <- LinearRegression_data[complete.cases(LinearRegression_data),]
    DataReturn <- rbind(DataReturn,LinearRegression_data)
    pb <- progress_bar$new(total = dim(SequencingTable)[1] - 1)
    pb$tick(0)
    for (i in 2:dim(SequencingTable)[1]){
      pb$tick()
      var1 <- zscore[i,]
      var2 <- l2fc[i,]
      linear_reg <- lm(var2~var1)
      LinearRegression_data <- data.frame(Sample = colnames(SequencingTable),
                                          Transcript = rep(row.names(SequencingTable)[i],ncol(SequencingTable)),
                                          value = as.numeric(SequencingTable[i,]),
                                          reconstruction = as.numeric(ReconstructedTable[i,]),
                                          zscore=var1,
                                          l2fc=var2,
                                          typeerror=rstandard(linear_reg),
                                          cooksD=cooks.distance(linear_reg),
                                          hat=hatvalues(linear_reg),
                                          dfbetas_intercept=dfbetas(linear_reg)[,1],
                                          dfbetas_var=dfbetas(linear_reg)[,2],
                                          nb_pval = pnbinom(q = SequencingTable[i,], size = nb_pval[i], mu = ReconstructedTable[i,]),
                                          row.names = NULL)
      LinearRegression_data['predict'] <- decision_tree(LinearRegression_data)
      LinearRegression_data <- LinearRegression_data[LinearRegression_data$predict == TRUE,]
      LinearRegression_data <- LinearRegression_data[complete.cases(LinearRegression_data), ]
      DataReturn <- rbind(DataReturn,LinearRegression_data)}
    DataReturn <- DataReturn[-1,]
    row.names(DataReturn) <- NULL
    return(DataReturn)
  }else{
    stop("Numerical vector or logical needed in nb_pval")
  }
}
