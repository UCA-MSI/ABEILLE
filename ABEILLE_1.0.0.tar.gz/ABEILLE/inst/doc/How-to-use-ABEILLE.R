## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----setup--------------------------------------------------------------------
library(ABEILLE)

## -----------------------------------------------------------------------------
toy_dataset <- ExampleAbeilleDataSet
print(paste("The dataframe contains",
            dim(toy_dataset)[1],"transcripts and",
            dim(toy_dataset)[2],"samples"))
head(toy_dataset[,1:6])

## -----------------------------------------------------------------------------
DataIntegrity(toy_dataset)

## -----------------------------------------------------------------------------
#To show the function RemoveZeroCounts let us add a row with only 0
toy_dataset[14001,] <- 0
print(dim(toy_dataset))
toy_dataset <- RemoveZeroCounts(toy_dataset)

## ----eval=FALSE---------------------------------------------------------------
#  write.csv(toy_dataset, "toy_dataset.csv")
#  #Don't add arguments

## ----eval=FALSE---------------------------------------------------------------
#  library(reticulate)
#  #Source my own python environment
#  #To find your python path you can use os.path.dirname(sys.executable) on python
#  use_python("C:/ProgramData/Anaconda3")
#  #If you don't have environment ready, you can load library needed in python
#  py_install("numpy")
#  py_install("pandas")
#  py_install("tensorflow")
#  #Load the VAE function
#  source_python("abeille.py")
#  toy_dataset_recons <- abeille_VAE("toy_dataset.csv")

## -----------------------------------------------------------------------------
toy_dataset_recons <- ExampleAbeilleReconstructed

## -----------------------------------------------------------------------------
StatsPred(toy_dataset, toy_dataset_recons)

## -----------------------------------------------------------------------------
zscore <- Zscore(toy_dataset, toy_dataset_recons)
l2fc <- L2FC(toy_dataset, toy_dataset_recons)

## -----------------------------------------------------------------------------
outliers <- PickOutliers(zscore, l2fc, toy_dataset, toy_dataset_recons)
print(head(outliers))

## -----------------------------------------------------------------------------
light_tree <- function(linear_reg_data){
  bool_vector <- ifelse(linear_reg_data["cooksD"] >= 15.0,TRUE,FALSE)
  return(bool_vector)
}
outliers <- PickOutliers(zscore, l2fc, toy_dataset, toy_dataset_recons, decision_tree = light_tree)
print(head(outliers))

## -----------------------------------------------------------------------------
genedisp <- GeneDisp(toy_dataset)
outliers <- PickOutliers(zscore, l2fc, toy_dataset, toy_dataset_recons, nb_pval = genedisp)
print(head(outliers))

## -----------------------------------------------------------------------------
anno_table <- data.frame(sampleID = colnames(toy_dataset), Sex = sample(c("Male", "Female"), 128, replace = TRUE), Age = sample(1:89, 128, replace = TRUE), Cohort = rep("GTEx database",128))
sizefactor <- SizeFactors(toy_dataset, anno_table)
print(head(sizefactor))

## -----------------------------------------------------------------------------
outrider_outliers <- AddOutriderOutliers(toy_dataset, sizefactor, drawoption = 10^-5)

## -----------------------------------------------------------------------------
gaussian_outliers <- AddGaussianOutliers(toy_dataset, drawoption = 10^-5)

